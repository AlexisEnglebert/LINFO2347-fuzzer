#pragma once

#include <stdio.h>
#include <string.h>
//devmajor, devminor, prefix or padding
typedef struct tar_struct
{                              /* byte offset */
    char name[100];               /*   0 */
    char mode[8];                 /* 100 */
    char uid[8];                  /* 108 */
    char gid[8];                  /* 116 */
    char size[12];                /* 124 */
    char mtime[12];               /* 136 */
    char chksum[8];               /* 148 */
    char typeflag;                /* 156 */
    char linkname[100];           /* 157 */
    char magic[6];                /* 257 */
    char version[2];              /* 263 */
    char uname[32];               /* 265 */
    char gname[32];               /* 297 */
    char devmajor[8];             /* 329 - Balek*/
    char devminor[8];             /* 337 - Balek*/
    char prefix[155];             /* 345  - Balek*/
    char padding[12];             /* 500 */
} tar_t;


extern int success_cnt;

int init_valid_tar(tar_t* tar);
unsigned int calculate_checksum(tar_t* entry);
int write_tar(tar_t* data, const char* folder, const char *content, size_t data_size);
int save_success_tar(tar_t* tar, const char* content, size_t data_size);